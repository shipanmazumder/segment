
<?php $__env->startSection('title_area'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
    <div class="container">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Welcome To Dashboard !</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="#">Admin</a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </div>
        </div>

        <!-- Start Widget -->
            <div class="row">
            </div>
        </div> <!-- container -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shipan\shipan7.3\htdocs\segment\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>