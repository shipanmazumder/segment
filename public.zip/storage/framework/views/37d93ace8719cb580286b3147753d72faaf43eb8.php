  <!-- ========== Left Sidebar Start ========== -->
  <div class="left side-menu">
        <div class="sidebar-inner slimscrollleft">
            <div class="user-details">
                <div class="pull-left">
                    <img src="<?php echo e(asset("admin")); ?>/images/logo.png" alt="" class="thumb-md img-circle">
                </div>
                <div class="user-info">
                    <div class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(config('app.name')); ?> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="md md-settings"></i> Reset Profile</a></li>
                        </ul>
                    </div>

                    <p class="text-muted m-0">Admin</p>
                </div>
            </div>
            <!--- Divider -->
            <div id="sidebar-menu">
                <ul>
                    <li>
                        <a href="<?php echo e(route("dashboard")); ?>" class="waves-effect <?php echo e(set_Topmenu("dashboard")); ?>"><i class="md md-home"></i><span> Dashboard </span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("subscribe.index")); ?>" class="waves-effect <?php echo e(set_Topmenu("subscribe")); ?>"><i class="ion ion-android-sort"></i><span> Subscribe </span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("segment.index")); ?>" class="waves-effect <?php echo e(set_Topmenu("segment")); ?>"><i class="ion ion-android-sort"></i><span> Segment </span></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- Left Sidebar End -->
<?php /**PATH F:\shipan\shipan7.3\htdocs\segment\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>