<?php $__env->startSection('title_area'); ?>
    Subscribe
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-<?php echo e(Session::get("class")); ?>"><?php echo e(Session::get("message")); ?></div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <form action="<?php echo e(route('subscribe.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-12">
                        <div class="panel-group panel-group-joined" id="accordion-test">
                            <div class="panel panel-border panel-info">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                            Subscribe
                                        </a>
                                    </h3>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse in">
                                    <div class="panel-body">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label for="first_name">First Name</label><small class="req">*</small>
                                                <input required   name="first_name" placeholder="First Name" type="text" class="form-control" id="first_name">
                                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label for="last_name">Last Name</label><small class="req">*</small>
                                                <input required   name="last_name" placeholder="Last Name" type="text" class="form-control" id="last_name">
                                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label for="email">Email</label><small class="req">*</small>
                                                <input required   name="email" placeholder="Email" type="email" class="form-control" id="email">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label for="birthday">Birthday</label><small class="req">*</small>
                                                <input required   name="birthday" placeholder="Birthday" type="text" readonly class="form-control" id="birthday">
                                                <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group pull-left m-t-22">
                                                <input type="submit" class=" btn btn-primary pull-right" value="Save" name="submit" />
                                            </div>
                                        </div>
                                    </div> <!-- panel-body -->
                                </div>
                            </div> <!-- panel -->
                        </div>
                    </div> <!-- col -->
                </form>
            </div> <!-- End row -->
            <div class="row">
                <div class="panel panel-border panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                Subscribe View
                            </a>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="segment_id">Segments</label><small class="req">*</small>
                                    <select name="segment_id" id="segment_id" class="form-control selectpicker">
                                        <option value="">--Select--</option>
                                        <?php if($segments): ?>
                                            <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">SL.</th>
                                            <th class="text-center">First Name</th>
                                            <th class="text-center">Last Name</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Birthday</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div> <!-- panel -->
            </div> <!-- End row -->
        </div> <!-- container -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('admin')); ?>/vendors/timepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo e(asset('admin')); ?>/vendors/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/vendors/datatables/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        var t;
        $("#segment_id").on("change",function(){
            $('#datatable').DataTable().clear().destroy();
            datatable();
            // $(this).submit();
        });
        jQuery('#birthday').datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: true,
            todayHighlight: true,
            autoclose: true
        });

        datatable();
        function datatable() {
            var segment_id=$("#segment_id").val();
            t=$("#datatable").DataTable({
            lengthMenu: [ 10, 25, 50, 75, 100,500],
            responsive: true,
            autoWidth :false,
            processing:true,
            serverSide:true,
            ordering:false,
            ajax:{
                url:"/subscribe/view?segment_id="+segment_id
            },
            columns:[
                    { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                    { "data": "first_name" },
                    { "data": "last_name" },
                    { "data": "email" },
                    { "data": "birthday" }
            ]
            });
        }

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shipan\shipan7.3\htdocs\segment\resources\views/admin/subscribe/index.blade.php ENDPATH**/ ?>