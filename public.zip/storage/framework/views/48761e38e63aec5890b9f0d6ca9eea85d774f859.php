<footer class="footer text-right">
        2018-<?php echo e(date("Y")); ?>

    </footer>
<?php /**PATH F:\shipan\shipan7.3\htdocs\segment\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>