<?php

namespace App\Repository;

interface SubscribeInterface
{
    public function datatableView($segment_id);
}
