<?php

namespace App\Repository;

interface SegmentInterface
{
    public function datatableView();
}
