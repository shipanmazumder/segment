@extends('admin.layout.default')
@section('title_area')
    Dashboard
@endsection
@section('main_section')
    <div class="content">
    <div class="container">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Welcome To Dashboard !</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="#">Admin</a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </div>
        </div>

        <!-- Start Widget -->
            <div class="row">
            </div>
        </div> <!-- container -->
    </div>
@endsection