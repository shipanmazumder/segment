<footer class="footer text-right">
        2018-{{date("Y")}}
    </footer>
